// todoModel.js
class Todo {
  constructor(id, task, completed) {
    this.id = id;
    this.task = task;
    this.completed = completed;
  }
}

module.exports = Todo;
